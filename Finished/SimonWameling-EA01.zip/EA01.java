/**
 * @author Simon Wameling
 * @version openjdk version "17.0.10" 2024-01-16
 */
public class EA01
{	public static void main( String[] args )
	{
		System.out.println("Moin!"); 
        System.out.println("Name: Simon Wameling");
        System.out.println("Tel: +4917647628308");
        System.out.println("Erfahrung: Ein bisschen C und C# und in der Schule Java und Python"); 
	}
}