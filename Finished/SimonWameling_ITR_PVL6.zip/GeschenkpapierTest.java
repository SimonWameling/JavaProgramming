import java.util.Scanner;

/**
 * Eine Klasse zum Testen von Geschenkpapier.java
 * 
 * @author Simon Wameling
 * @version openjdk version "17.0.10" 2024-01-16
 */

public class GeschenkpapierTest {
    public static void main(String[] args) {
        Scanner eingabe = new Scanner(System.in);
        boolean wiederholung = false;

        // Wiederholschleife für mehrfache Ausführung
        do {
            // Begruessung und Abfrage nach der Anzahl der Muster
            System.out.println("Hallo!");
            System.out.println("Moechtest du ein (1) oder zwei (2) Muster eingeben? (1/2)");
            int musteranzahl = eingabe.nextInt();
            // Unterscheidung zwischen 1 oder 2 Muster und entsprechender Aufruf der Methode
            // in Geschenkpapier
            switch (musteranzahl) {
                case 1:
                    System.out.println();
                    eingabe = new Scanner(System.in); // neuer Scanner, da nächste Eingabe übersprungen wird
                    Geschenkpapier.zeichneMuster(musterabfrage(eingabe), nummerabfrage("Zeilen", eingabe),
                            nummerabfrage("Spalten", eingabe));
                    break;
                case 2:
                    System.out.println();
                    eingabe = new Scanner(System.in); // neuer Scanner, da nächste Eingabe übersprungen wird
                    Geschenkpapier.zeichneMuster(musterabfrage(eingabe), musterabfrage(eingabe),
                            nummerabfrage("Zeilen", eingabe), nummerabfrage("Spalten", eingabe));
                    break;
                default:
                    System.out.println("Falsche Eingabe");
                    break;
            }
            System.out.println("Nochmal? (true/false)");
            wiederholung = eingabe.nextBoolean();
        } while (wiederholung);
        eingabe.close();
    }

    /**
     * Methode zur Eingabe des Musters
     * 
     * @param input der Scanner für die Eingabe
     * @return Das Muster als String
     */
    private static String musterabfrage(Scanner input) {
        System.out.println("Gib das Muster ein? ");
        return input.nextLine();
    }

    /**
     * Methode zur Eingabe der Zeilen oder Spaltenanzahl
     * 
     * @param input der Scanner für die Eingabe
     * @return Anzahl als Integer
     */
    private static int nummerabfrage(String pZeilenOderSpalten, Scanner input) {
        System.out.println("Gibt die Anzahl an " + pZeilenOderSpalten + " ein! ");
        return input.nextInt();
    }
}
