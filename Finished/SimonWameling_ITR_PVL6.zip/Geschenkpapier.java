/**
 * Eine Klasse zur Ausgabe von Mustern.
 * 
 * @author Simon Wameling
 * @version openjdk version "17.0.10" 2024-01-16
 */

public class Geschenkpapier {
    /**
     * Zeichnet das Muster in der gegeben Anzahl an Zeilen und Spalten
     * 
     * @param pMuster  Das auszugebende Muster
     * @param pZeilen  Die Anzahl der Zeilen
     * @param pSpalten Die Anzahl der Spalten
     */
    public static void zeichneMuster(String pMuster, int pZeilen, int pSpalten) {
        int zeile = 1;
        while (zeile <= pZeilen) {
            int spalte = 1;
            while (spalte <= pSpalten) {
                // Muster und ein Leerzeichen zur Separation der Muster augeben
                System.out.print(pMuster + " ");
                spalte++;
            }
            System.out.println();
            zeile++;
        }
    }

    /**
     * Zeichnet zwei Muster zeilenweise abwechselnd in der gegeben Anzahl an Zeilen
     * und Spalten
     * 
     * @param pMuster1 Das erste auszugebende Muster
     * @param pMuster2 Das zweite auszegebende Muster
     * @param pZeilen  Die Anzahl der Zeilen
     * @param pSpalten Die Anzahl der Spalten
     */
    public static void zeichneMuster(String pMuster1, String pMuster2, int pZeilen, int pSpalten) {
        for (int zeile = 1; zeile <= pZeilen; zeile++, System.out.println()) {
            for (int spalte = 1; spalte <= pSpalten; spalte++) {
                // Fuer ungerade Zeilen das erste Muster ausgeben (z.B. Zeile 1) und fuer gerade
                // das zweite
                if (zeile % 2 != 0) {
                    // Muster 1 und ein Leerzeichen zur Separation der Muster augeben
                    System.out.print(pMuster1 + " ");
                } else {
                    // Muster 2 und ein Leerzeichen zur Separation der Muster augeben
                    System.out.print(pMuster2 + " ");
                }
            }
        }
    }
}
