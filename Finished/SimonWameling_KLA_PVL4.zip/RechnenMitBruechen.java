import java.util.Scanner;

import mathematik.Bruch;

/**
 * Klasse zum Rechnen mit Bruechen aus {@link mathematik.Bruch}
 * 
 * @author Simon Wameling
 * @version openjdk version "17.0.10" 2024-01-16
 */

public class RechnenMitBruechen {
    public static void main(String[] args) {
        Bruch b1, b2, b3;

        System.out.println("Bruch 1: ");
        b1 = befuellen();
        b1.kuerzen();
        System.out.println(b1.toString() + " \n");
        System.out.println("Bruch 2: ");
        b2 = befuellen();
        b2.kuerzen();
        System.out.println(b2.toString() + " \n");

        System.out.println("Es wurden " + b1.toString() + " und " + b2 + " eingegeben.");

        b3 = b1.multiplizieren(b2);
        b3.kuerzen();
        System.out.println("Multipliziert: " + b3.toString() + " (" + b3.ausrechnen() + ")");
    }

    private static Bruch befuellen() {
        long tZaehler = aufforderungInt("Bitte gib den Zaehler ein: ");
        long tNenner = aufforderungInt("Bitte gib den Nenner ein: ");
        Bruch b = new Bruch(tZaehler, tNenner);
        return b;
    }

    private static long aufforderungInt(String Ausgabe) {
        System.out.print(Ausgabe);
        Scanner eingabe = new Scanner(System.in);
        long temp = eingabe.nextLong();
        return temp;
    }
}
