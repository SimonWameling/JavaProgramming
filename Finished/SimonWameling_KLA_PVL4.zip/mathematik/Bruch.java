package mathematik;

/**
 * Diese Klasse stellt einen mathematischen Bruch dar
 * 
 * @author Simon Wameling
 * @version openjdk version "17.0.10" 2024-01-16
 */
public class Bruch {
    private long zaehler;
    private long nenner;

    /**
     * Erstellt einen Bruch mit den gegebenen Parametern
     * Wenn Nenner < 1 ist, wird er auf 1 gesetzt
     * 
     * @param pZaehler Zaehler des Bruchs
     * @param pNenner  Nenner des Bruchs (muss größer 0 sein)
     */
    public Bruch(long pZaehler, long pNenner) {
        this.zaehler = pZaehler;
        if (pNenner > 0) {
            this.nenner = pNenner;
        } else {
            System.out.println("Nenner muss > 0 sein!");
            this.nenner = 1;
        }
    }

    /**
     * Erstellt einen Bruch mit den gegebenen Parametern
     * Wenn nicht angegeben ist der Nenner = 1
     * 
     * @param pZaehler Zaehler des Bruchs
     */
    public Bruch(long pZaehler) {
        this(pZaehler, 1);
    }

    /**
     * Berechnung des ggT zweier Zahlen
     * nach dem Euklidischen Algorithmus
     * Quelle: https://unterrichten.zum.de/wiki/Java/ggT
     * 
     * @param zahl1
     * @param zahl2
     * @return int - groesster gemeinsamer Teiler
     */
    private static long ggt(long zahl1, long zahl2) {
        zahl1 = machPositiv(zahl1);
        zahl2 = machPositiv(zahl2);
        while (zahl2 != 0) {
            if (zahl1 > zahl2) {
                zahl1 = zahl1 - zahl2;
            } else {
                zahl2 = zahl2 - zahl1;
            }
        }
        return zahl1;
    }

    /**
     * Gibt den Betrag der Zahl zurück
     * 
     * @param zahl
     * @return int Betrag der Zahl
     */
    private static long machPositiv(long zahl) {
        if (zahl < 0) {
            zahl *= -1;
        }
        return zahl;
    }

    /**
     * Multipiziert den aktuellen Bruch mit dem gegebenen
     * 
     * @param b
     * @return Bruch - Ergebnis der Mulpitplikation
     */
    public Bruch multiplizieren(Bruch b) {
        b.nenner *= this.nenner;
        b.zaehler *= this.zaehler;
        return b;
    }

    /**
     * Rechnet den Bruch in eine Kommazahl um
     * Es können Rundungsfehler auftreten
     * 
     * @return double
     */
    public double ausrechnen() {
        double n = this.nenner;
        double z = this.zaehler;
        return (z / n);
    }

    /**
     * kuerzt den Bruch
     * 
     * @return boolean true wenn der Bruch gekuerzt wurde
     */
    public boolean kuerzen() {
        long divisor = ggt(this.zaehler, this.nenner);
        if (divisor > 1) {
            this.zaehler /= divisor;
            this.nenner /= divisor;
            return true;
        }
        return false;
    }

    /**
     * liefert eine String-Darstellung des Bruches
     */
    public String toString() {
        return (this.zaehler + "/" + this.nenner);
    }

    /* Getter */
    public long getNenner() {
        return this.nenner;
    }

    public long getZaehler() {
        return this.zaehler;
    }
}
