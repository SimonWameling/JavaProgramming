import java.util.Base64;

/**
 * Dies ist ein Programm zur Verschluesselung mit dem Vigenere-Verfahren
 * 
 * @author Simon Wameling
 * @version openjdk version "17.0.10" 2024-01-16
 */

class Vigenere {

    /**
     * Verschluesselt den eingegebenen Klartext per
     * Vigenere-Verfahren mit dem eingegebenen Schluessel
     * Es können nur Buchstaben eingegeben werden
     * 
     * @param args Klartext Schluessel
     */
    public static void main(String[] args) {
        // Zeichenbereichsdefinition
        int anfangBereich = 32;
        int endeBereich = 126; // ohne DEL
        int anzahlZeichen = endeBereich - anfangBereich + 1;
        boolean useBase64encoding = false;

        // Eingabeprüfung
        if (args.length != 2) {
            System.out.println("Bitte gib zwei Parameter ein! \n \n'java Vigenere <Klartext> <Schluessel>' \n ");
            return;
        }

        // Argumente als char-Arrays in Variablen schreiben
        char[] textChar = args[0].toCharArray();
        char[] keyChar = args[1].toCharArray();

        // Ausgabe als Test
        System.out.print("Klartext: ");
        for (char c : textChar)
            System.out.print(c);
        System.out.println();
        System.out.print("Schluessel: ");
        for (char c : keyChar)
            System.out.print(c);
        System.out.println();

        // Eingabeprüfung
        try {
            for (char c : textChar) {
                if ((int) c < anfangBereich || c > endeBereich) {
                    throw new ZeichenbereichException("Zeichen '" + c + "' ist ausserhalb des Zeichenbereichs");
                }
            }

            // Ausnahmebehandlung
        } catch (ZeichenbereichException e) {
            System.err.println(e);
            System.out.println("Base64-Kodierung wird verwendet!");

            useBase64encoding = true;
        }

        // zu Base64 kodieren, wenn benoetigt
        if (useBase64encoding) {
            textChar = encodeBase64(textChar.toString()).toCharArray();
            System.out.println("Kodierter String: " + textChar.toString());
        }

        // char-Array in die jeweiligen Zahlenwerte umwandeln
        int[] textInt = new int[textChar.length];
        for (int i = 0; i < textInt.length; i++)
            textInt[i] = ((int) textChar[i] - anfangBereich);
        int[] keyInt = new int[keyChar.length];
        for (int i = 0; i < keyInt.length; i++)
            keyInt[i] = ((int) keyChar[i] - anfangBereich);

        // Klartext wird mit dem Schluessel addiert. Falls der Schluessel zu kurz ist,
        // wird er wiederholt.
        for (int i = 0; i < textInt.length; i++) {
            textInt[i] = (textInt[i] + keyInt[i % keyInt.length]) % anzahlZeichen;
        }
        System.out.println();

        // Ausgabe
        System.out.println("Der verschluesselte Text ist: ");
        for (int c : textInt)
            System.out.print(((char) (c + anfangBereich)));
        System.out.println("\n");
    }

    /**
     * Method encodes a string to Base64
     * 
     * @param original
     * @return String encoded in Base64
     */
    private static String encodeBase64(String original) {
        return Base64.getEncoder().withoutPadding().encodeToString(original.getBytes());
    }
}