public class ZeichenbereichException extends Exception {
    public ZeichenbereichException() {
        super();
    }

    public ZeichenbereichException(String message) {
        super(message);
    }
}
