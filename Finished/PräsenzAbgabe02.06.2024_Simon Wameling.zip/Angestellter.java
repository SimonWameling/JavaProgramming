/**
 * Klasse Angestellter erbt von Mensch und erweitert diese Klasse
 * 
 * @author Simon Wameling
 * @version openjdk version "17.0.10" 2024-01-16
 */

public class Angestellter extends Mensch {
    int gehalt;
    String firma;
    String taetigkeit;

    // Standardkonstruktor
    public Angestellter() {
        super();
    }

    // Konstruktor mit Name und GebDatum
    public Angestellter(String[] pVorname, String pNachname, String pGeburtsdatum) {
        super(pVorname, pNachname, pGeburtsdatum);
        this.gehalt = 0;
        this.firma = "k.A.";
        this.taetigkeit = "k.A.";
    }

    // Konstruktor mit allen Parametern
    public Angestellter(String[] pVorname, String pNachname, String pGeburtsdatum, int pGehalt, String pFirma,
            String pTaetigkeit) {
        super(pVorname, pNachname, pGeburtsdatum);
        this.gehalt = pGehalt;
        this.firma = pFirma;
        this.taetigkeit = pTaetigkeit;
    }

    public String toString() {
        return super.toString() + "\nGehalt " + this.gehalt + "\nFirma " + this.firma + "\nTaetigkeit "
                + this.taetigkeit + "\n";
    }
}
