/**
 * Klasse Selbststaendiger erbt von Mensch und erweitert diese Klasse
 * 
 * @author Simon Wameling
 * @version openjdk version "17.0.10" 2024-01-16
 */

public class Selbststaendiger extends Mensch {
    String steuernummer;
    String taetigkeit;
    String handelsregisterEintrag;

    // Standardkonstruktor
    public Selbststaendiger() {
        super();
        this.steuernummer = "k.A.";
        this.taetigkeit = "k.A.";
        this.handelsregisterEintrag = "k.A.";
    }

    // Konstruktor mit Name und GebDatum
    public Selbststaendiger(String[] pVorname, String pNachname, String pGeburtsdatum) {
        super(pVorname, pNachname, pGeburtsdatum);

    }

    // Konstruktor mit allen Parametern
    public Selbststaendiger(String[] pVorname, String pNachname, String pGeburtsdatum, String pSteuernummer,
            String pTaetigkeit, String pHandelsregisterEintrag) {
        super(pVorname, pNachname, pGeburtsdatum);
        this.steuernummer = pSteuernummer;
        this.taetigkeit = pTaetigkeit;
        this.handelsregisterEintrag = pHandelsregisterEintrag;
    }

    public String toString() {
        return super.toString() + "\nSteuernummer " + this.steuernummer + "\nTaetigkeit " + this.taetigkeit
                + "\nHandlsreg. " + this.handelsregisterEintrag + "\n";
    }
}