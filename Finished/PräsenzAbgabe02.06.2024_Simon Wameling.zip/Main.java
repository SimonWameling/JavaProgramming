/**
 * Main-Klasse zum Ausfuehren und Testen
 * Platzhalter, wenn keine Daten vorhanden sind, ist "k.A"
 * 
 * @author Simon Wameling
 * @version openjdk version "17.0.10" 2024-01-16
 */

public class Main {
    public static void main(String[] args) {
        // Familie erstellen
        // Eltern erstellen
        Elternteil mutter = new Elternteil(new String[] { "Marie" }, "Doe", "03.05.1982");
        Elternteil vater = new Elternteil(new String[] { "Peter" }, "Doe", "05.02.1983", mutter);
        mutter.ehepartner = vater;
        // Adresse hinzufügen
        String adresse = "Neuer Weg 5, 30574 Einhornstadt";
        mutter.adresse = adresse;
        vater.adresse = adresse;
        // Kinder erstellen
        Mensch kind1 = new Mensch(new String[] { "John" }, "Doe", "01.05.2002", vater, mutter);
        Mensch kind2 = new Mensch(new String[] { "Jimbo" }, "Doe", "21.03.2005", vater, mutter);
        Mensch[] kinder = { kind1, kind2 };
        mutter.kinder = kinder;
        vater.kinder = kinder;
        // Familie anzeigen
        System.out.println(mutter);
        System.out.println(vater);
        System.out.println(kind1.toStringMitEltern());
        System.out.println(kind2.toStringMitEltern());

        // Selbststaendigen anlegen
        Selbststaendiger selbststaendiger1 = new Selbststaendiger();
        System.out.println(selbststaendiger1);
        // Selbstständigen mit Daten anlegen
        Selbststaendiger selbststaendiger2 = new Selbststaendiger(new String[] { "Martin" }, "Mueller", "20.10.1990",
                "32184357", "Mueller", "HandelsregistereintragTest");
        System.out.println(selbststaendiger2);

        // Angestellten anlegen
        Angestellter angestellter1 = new Angestellter(new String[] { "Tina" }, "Niewer", "12.02.2001", 2000,
                "OnlineShop123 GmbH", "Designer m/w/d");
        System.out.println(angestellter1);

        // Mensch anlegen standard
        Mensch mensch1 = new Mensch();
        System.out.println(mensch1);
        System.out.println(); // extra Zeile für lesbarkeit
        // Mensch anlegen komplett
        Mensch mensch2 = new Mensch(new String[] { "Timo", "Werner", "Dieter" }, "Mustermann", "12.04.2024",
                selbststaendiger1, angestellter1);
        System.out.println(mensch2.toStringMitEltern());
    }
}
