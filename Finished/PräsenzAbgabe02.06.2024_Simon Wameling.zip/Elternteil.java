/**
 * Klasse Elternteil erbt von Mensch und erweitert diese Klasse
 * 
 * @author Simon Wameling
 * @version openjdk version "17.0.10" 2024-01-16
 */

public class Elternteil extends Mensch {
    Mensch ehepartner;
    Mensch[] kinder;
    String adresse;

    // Standardkonstruktor
    public Elternteil() {
        super();
        this.adresse = "k.A";
    }

    // Konstruktor mit Namen und GebDatum
    public Elternteil(String[] pVorname, String pNachname, String pGebDatum) {
        super(pVorname, pNachname, pGebDatum);
        this.adresse = "k.A";
    }

    // Konstruktor mit Namen, GebDatum und Ehepartner
    public Elternteil(String[] pVorname, String pNachname, String pGebDatum, Mensch pEhepartner) {
        super(pVorname, pNachname, pGebDatum);
        this.ehepartner = pEhepartner;
        this.adresse = "k.A";
    }

    // vollstaendiger Konstruktor
    public Elternteil(String[] pVorname, String pNachname, String pGeburtsdatum, Mensch pEhepartner, Mensch[] pKinder,
            String pAdresse) {
        super(pVorname, pNachname, pGeburtsdatum);
        this.ehepartner = pEhepartner;
        this.kinder = pKinder;
        this.adresse = pAdresse;
    }

    public String toString() {
        String kinderString = arrayString(kinder);
        return super.toString() + "\nEhepartner " + this.ehepartner.getName() + "\nKinder " + kinderString
                + "\nAdresse "
                + this.adresse + "\n";
    }
}
