/**
 * Klasse Mensch modeliert einen Menschen
 * 
 * @author Simon Wameling
 * @version openjdk version "17.0.10" 2024-01-16
 */

public class Mensch {
    String[] vorname; // Stringarray für mehrere Vornamen
    String nachname;
    String geburtsdatum;
    Mensch vater, mutter;

    // Standardkonstruktor
    public Mensch() {
        this.vorname = new String[] { "John", Integer.toHexString(hashCode()) }; // Einfuegen des Hashcodes zur
                                                                                 // eindeutigen Identifizierung
        this.nachname = "Doe";
        this.geburtsdatum = "k.A.";
    }

    // Konstruktor mit Name und GebDatum
    public Mensch(String[] pVorname, String pNachname, String pGeburtsdatum) {
        this.vorname = pVorname;
        this.nachname = pNachname;
        this.geburtsdatum = pGeburtsdatum;
    }

    // Konstruktor mit allen Parametern
    public Mensch(String[] pVorname, String pNachname, String pGeburtsdatum, Mensch pVater, Mensch pMutter) {
        this.vorname = pVorname;
        this.nachname = pNachname;
        this.geburtsdatum = pGeburtsdatum;
        this.vater = pVater;
        this.mutter = pMutter;
    }

    // Vornamen zurueckgeben
    public String getVorname() {
        return arrayString(this.vorname);
    }

    // ganzen NAmen zurückgeben
    public String getName() {
        return this.getVorname() + this.nachname;
    }

    public String toString() {
        String vornameString = arrayString(vorname);
        return vornameString + this.nachname + " " + this.geburtsdatum + " ";
    }

    // Damit toString ueberall einsetzbar ist, ist die Ausgabe der Eltern dort nicht
    // eingebaut und stattdessen hier mit drin
    public String toStringMitEltern() {
        return this.toString() + "\n\nVater: \n" + this.vater + "\nMutter: \n" + this.mutter;
    }

    /**
     * Methode zur Umwandlung von String[] zu einem String zur Ausgabe
     * 
     * @param pArray
     * @return String mit Leerzeichen als Padding
     */
    protected static String arrayString(String[] pArray) {
        String tempString = "";
        for (String a : pArray) {
            tempString += a + " ";
        }
        return tempString;
    }

    /**
     * Methode zur Ausgabe von Menschen im Array
     * 
     * @param pArray
     * @return String der Ausgabe fuer die Menschen im Array
     */
    protected static String arrayString(Mensch[] pArray) {
        String tempString = "k.A.";
        if (pArray != null) {
            tempString = "";
            for (Mensch a : pArray) {
                tempString += " " + a.toString() + " ";
            }
        }
        return tempString;
    }

}