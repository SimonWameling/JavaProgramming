/**
 * Dies ist ein Programm zur Verschluesselung mit dem Vigenere-Verfahren
 * 
 * @author Simon Wameling
 * @version openjdk version "17.0.10" 2024-01-16
 */

class Vigenere {

    /**
     * Verschluesselt den eingegebenen Klartext per
     * Vigenere-Verfahren mit dem eingegebenen Schluessel
     * Es können nur Buchstaben eingegeben werden
     * 
     * @param args Klartext Schluessel
     */
    public static void main(String[] args) {
        // Zeichenbereichsdefinition
        int anfangBereich = (int) 'a';
        int endeBereich = (int) 'z';
        int anzahlZeichen = endeBereich - anfangBereich + 1;

        // Eingabeprüfung
        if (args.length < 2 || args.length > 2) {
            System.out.println("Bitte gib zwei Parameter ein! \n \n'java Vigenere <Klartext> <Schluessel>' \n ");
            return;
        }

        // Argumente als char-Arrays in Variablen schreiben
        args[0] = args[0].toLowerCase();
        args[1] = args[1].toLowerCase();
        char[] textChar = args[0].toCharArray();
        char[] keyChar = args[1].toCharArray();

        // Ausgabe als Test
        System.out.print("Klartext: ");
        for (char c : textChar)
            System.out.print(c);
        System.out.println();
        System.out.print("Schluessel: ");
        for (char c : keyChar)
            System.out.print(c);
        System.out.println();

        // char-Array in die jeweiligen Zahlenwerte umwandeln. kleines a = 0.
        int[] textInt = new int[textChar.length];
        for (int i = 0; i < textInt.length; i++)
            textInt[i] = ((int) textChar[i] - anfangBereich);
        int[] keyInt = new int[keyChar.length];
        for (int i = 0; i < keyInt.length; i++)
            keyInt[i] = ((int) keyChar[i] - anfangBereich);

        // Klartext wird mit dem Schluessel addiert. Falls der Schluessel zu kurz ist,
        // wird er wiederholt.
        for (int i = 0; i < textInt.length; i++) {
            textInt[i] = betrag((textInt[i] + keyInt[i % keyInt.length]) % anzahlZeichen);
        }
        System.out.println();

        // Ausgabe (muss wieder mit 'a' addiert werden)
        System.out.println("Der verschluesselte Text ist: ");
        for (int c : textInt)
            System.out.print(((char) (c + (int) 'a')));
        System.out.println("\n");
    }

    /**
     * Diese Methode berechnet den Betrag einer Zahl
     * 
     * @param p int
     * @return
     */
    private static int betrag(int p) {
        if (p < 0)
            p *= -1;
        return p;
    }
}