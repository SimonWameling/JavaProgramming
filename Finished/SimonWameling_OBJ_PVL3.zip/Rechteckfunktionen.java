import java.awt.*;

/**
 * Die Klasse Rechteckfunktionen stellt Methoden fuer Rechtecke bereit
 * 
 * @author Simon Wameling
 * @version openjdk version "17.0.10" 2024-01-16
 */

public class Rechteckfunktionen {
    /**
     * Die Methode erzeugt ein neues Objekt der Klasse Rectangle der Groeße 10x10
     * und gibt es als Rueckgabewert zurueck
     * 
     * @return Rectangle
     */
    public static Rectangle rechteckErzeugen() {
        return new Rectangle(10, 10);
    }

    /**
     * Die Methode erhoeht die y - Koordinate des Rectangle - Objekt r um 1
     * Das Rechteck wird so nach unten verschoben
     * 
     * @param r Das zu verschiebende Rechteck
     */
    public static void verschiebeEinsRunter(Rectangle r) {
        r.translate(0, 1);
    }

    /**
     * Die Methode erhoeht die x - Koordinate des Rectangle - Objekt r um 1
     * Das Rechteck wird so nach rechts verschoben
     * 
     * @param r Das zu verschiebende Rechteck
     */
    public static void verschiebeEinsRechts(Rectangle r) {
        r.translate(1, 0);
    }

    /**
     * Die Methode setzt die x - und y - Koordinate von r auf 0
     * Das Rechteck wird zum Ursprung zurueckgesetzt
     * 
     * @param r Das zu verschiebende Rechteck
     */
    public static void anDenNullpunkt(Rectangle r) {
        r.setLocation(0, 0);
    }

}
