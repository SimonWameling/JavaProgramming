import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * Zeichnet ein Rechteck und schiebt es ueber die Oberflaeche
 * 
 */
public class Rechteckoberflaeche extends JFrame {
    private static final long serialVersionUID = 1L;

    private class RechteckPanel extends JPanel {
        private static final long serialVersionUID = 1L;

        public void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setColor(Color.WHITE);
            g2d.fillRect(0, 0, this.getWidth(), this.getHeight());
            g2d.setColor(Color.BLACK);
            g2d.draw(r);
        }
    }

    private JPanel panel;
    private Rectangle r = Rechteckfunktionen.rechteckErzeugen();

    /**
     * erstellt die Oberflaeche und bringt sie auf den Bildschirm
     */
    public Rechteckoberflaeche() {
        setLayout(new BorderLayout());
        panel = new RechteckPanel();
        add(panel, BorderLayout.CENTER);
        JPanel buttonleiste = new JPanel();
        buttonleiste.setLayout(new FlowLayout());
        JButton btnRunter = new JButton("runter");
        btnRunter.addActionListener(e -> {
            Rechteckfunktionen.verschiebeEinsRunter(r);
            panel.repaint();
        });
        buttonleiste.add(btnRunter);
        JButton btnSeit = new JButton("seit");
        btnSeit.addActionListener(e -> {
            Rechteckfunktionen.verschiebeEinsRechts(r);
            panel.repaint();
        });
        buttonleiste.add(btnSeit);
        JButton btnNull = new JButton("zurueck");
        btnNull.addActionListener(e -> {
            Rechteckfunktionen.anDenNullpunkt(r);
            panel.repaint();
        });
        buttonleiste.add(btnNull);
        add(buttonleiste, BorderLayout.SOUTH);

        this.setSize(300, 300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    /**
     * erstellt die Oberflaeche und bringt sie auf den Bildschirm
     * 
     * @param args wird nicht verwendet
     */
    public static void main(String[] args) {
        new Rechteckoberflaeche();
    }
}
